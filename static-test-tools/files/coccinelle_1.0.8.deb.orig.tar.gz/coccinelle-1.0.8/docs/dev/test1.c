void main(void)
{
	int a;
	a = 18;
}
