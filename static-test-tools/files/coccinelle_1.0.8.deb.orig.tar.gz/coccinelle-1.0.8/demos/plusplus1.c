struct x {
	int z;
	char b;
};
