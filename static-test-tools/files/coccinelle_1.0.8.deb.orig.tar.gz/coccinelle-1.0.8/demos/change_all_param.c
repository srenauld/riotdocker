int foo(int a, int b)
{
	return a + b;
}

int bar(int a, int b, int c)
{
	return a + b + c;
}

void main(void)
{
	int res;
	int x,y,y;

	res = foo(x,y);

	res = bar(x,y,z);
}
