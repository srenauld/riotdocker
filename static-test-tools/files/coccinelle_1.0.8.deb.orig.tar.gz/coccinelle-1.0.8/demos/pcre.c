
void foo() {

	WINE_ERR(0);
}
