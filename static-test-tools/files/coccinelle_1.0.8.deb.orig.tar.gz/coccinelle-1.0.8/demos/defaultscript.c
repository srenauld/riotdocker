int main () {
  one(12);
  one(nothing);
  other(nothing);
  other(12);
  return x;
}
