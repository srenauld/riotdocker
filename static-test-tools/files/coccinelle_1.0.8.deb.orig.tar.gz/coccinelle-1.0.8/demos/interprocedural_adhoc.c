
void ioctl(int i)
{

  g(1);
  h(2);
  w(3);
  z(4);

}





void g(int i) {
  bar(1);
}

void h(int i) {
  bar(1);
}

void w(int i) {
  bar(1);
}

void z(int i) {
  bar(1);
}
