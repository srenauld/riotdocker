int main() {
  printf("Hello world!");
  return 0;
}
