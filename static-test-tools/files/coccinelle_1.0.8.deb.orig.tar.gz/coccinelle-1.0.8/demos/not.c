int main() {
  int x;
  this(12,x);
  this(foo,x);
  bar(12,x);
  foo(12,x);
  this(12,x);
  this(12,x);
}
