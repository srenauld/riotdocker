int main() {
	int	foo;
	foo = 1000;
	return 0;
}
